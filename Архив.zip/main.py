from flask import Flask, url_for

from utils import milk_goods, popular_goods, meat_goods, bread_goods

app = Flask(__name__)


@app.route("/") 
@app.route("/home")
def home_page():
    goods1 = popular_goods()
    list = []
    for name in goods1:
      list.append(
        f'<li class="list-group-item"><a href="/shop/{name}" class="text-decoration-none">{name}</a></li>'
        )
      F_list = " ".join(list) 
    return f"""
        <!DOCTYPE html>
        <html lang="ru">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Магозин</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
          <link rel="stylesheet" href="{url_for('static', filename='css/style.css')}">
        </head>
        <body>
            <header>
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="home">Главная</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="bread">Хлебобулочные изделия</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="milk">Кисломолочные продукты</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="meat">Мясо</a>
                    </li>
                </ul>
            </header>

            <div class="container">
              <div class="row mt-5">
                <h1 class="text-center mt-5 mb-5">Популярные товары</h1>
                <div class="row justify-content-center">
                  <div class="col-md-4">
                    <ul class="list-group">
                      {F_list}
                    </ul>
                  </div>
                </div>
              </div>
          </div>

        </body>
        </html>
    """
 
@app.route("/milk")
def milk_page():
    goods = milk_goods()
    list = []
    for name in goods:
      list.append(
        f'<li class="list-group-item"><a href="/shop/{name}" class="text-decoration-none">{name}</a></li>'
        )
      F_list = " ".join(list)
      
    return f"""
        <!DOCTYPE html>
        <html lang="ru">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Магозин</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
          <link rel="stylesheet" href="{url_for('static', filename='css/style.css')}">
        </head>
        <body>
          <header>
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="milk">Кисломолочные продукты</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="home">Главная</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="bread">Хлебобулочные изделия</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="meat">Мясо</a>
                    </li>
                </ul>
            </header>

          <div class="container">
              <div class="row mt-5">
                <h1 class="text-center mt-5 mb-5">Популярные товары</h1>
                <div class="row justify-content-center">
                  <div class="col-md-4">
                    <ul class="list-group">
                      {F_list}
                    </ul>
                  </div>
                </div>
              </div>
          </div>
        </body>
        </html>
    """

@app.route("/meat")
def meat_page():
    goods = meat_goods()
    list = []
    for name in goods:
      list.append(
        f'<li class="list-group-item"><a href="/shop/{name}" class="text-decoration-none">{name}</a></li>'
        )
      F_list = " ".join(list)
      
    return f"""
        <!DOCTYPE html>
        <html lang="ru">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Магозин</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
          <link rel="stylesheet" href="{url_for('static', filename='css/style.css')}">
        </head>
        <body>
          <header>
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="meat">Мясо</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="home">Главная</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="bread">Хлебобулочные изделия</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="milk">Кисломолочные продукты</a>
                    </li>
                </ul>
            </header>

          <div class="container">
              <div class="row mt-5">
                <h1 class="text-center mt-5 mb-5">Популярные товары</h1>
                <div class="row justify-content-center">
                  <div class="col-md-4">
                    <ul class="list-group">
                      {F_list}
                    </ul>
                  </div>
                </div>
              </div>
          </div>
        </body>
        </html>
    """

@app.route("/bread")
def bread_page():
    goods = bread_goods()
    list = []
    for name in goods:
      list.append(
        f'<li class="list-group-item"><a href="/shop/{name}" class="text-decoration-none">{name}</a></li>'
        )
      F_list = " ".join(list)
      
    return f"""
        <!DOCTYPE html>
        <html lang="ru">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Магозин</title>
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
          <link rel="stylesheet" href="{url_for('static', filename='css/style.css')}">
        </head>
        <body>
          <header>
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="bread">Хлебобулочные изделия</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="home">Главная</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="milk">Кисломолочные продукты</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="meat">Мясо</a>
                    </li>
                </ul>
            </header>

          <div class="container">
              <div class="row mt-5">
                <h1 class="text-center mt-5 mb-5">Популярные товары</h1>
                <div class="row justify-content-center">
                  <div class="col-md-4">
                    <ul class="list-group">
                      {F_list}
                    </ul>
                  </div>
                </div>
              </div>
          </div>
        </body>
        </html>
    """


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug = True)