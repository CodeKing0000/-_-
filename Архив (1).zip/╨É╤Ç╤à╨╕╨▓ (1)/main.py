from flask import Flask, render_template
from utils import *

app = Flask(__name__)

@app.route('/')
def index():
    authors = get_all_authors()
    return render_template('index.html', authors = authors)

@app.route('/authors/<int:author_id>')
def author_page(id):
   print(id, type(id))
   author = get_author_by_id(id)
   return render_template('author.html', author = author)

if __name__ == '__main__':
  app.run(host='0.0.0.0', port=80, debug=True)