import sqlite3
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import create_engine, Column, Integer, String, Float

BaseModel = declarative_base()

engine = create_engine("sqlite:///data.db")



Session = sessionmaker(bind=engine)

session = Session()


class Book(BaseModel):
    __tablename__ = 'book'  

    id_author = Column(Integer, primary_key=True)  
    title = Column(String)  
    pages = Column(Integer)  
    year = Column(Integer)
    rating = Column(Float)
    price = Column(Float)
    author_id = Column(Integer)

class Author(BaseModel):
    __tablename__ = 'author'  

    id = Column(Integer, primary_key=True)  
    name = Column(String)  
    country = Column(String)  
    avatar_url = Column(String)


BaseModel.metadata.create_all(engine)

def get_all_authors():
    print(session.query(Author).all())
    all_authors = session.query(Author).all()  # all() — все записи


def get_author_by_id(id_author):
    author = session.query(Author).filter(id_author == id_author).first()